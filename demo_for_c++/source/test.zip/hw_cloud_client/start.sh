#!/bin/bash
chmod +x build/client
./build/client $1 $2 $3
